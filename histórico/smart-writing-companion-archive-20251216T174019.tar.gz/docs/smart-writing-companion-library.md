# Biblioteca de Funcionalidades e Serviços - SmartWriting Companion

Este documento serve como referência técnica para os serviços, analisadores e componentes centrais desenvolvidos no projeto **SmartWriting Companion**.

## 1. Arquitetura Geral

O plugin segue uma arquitetura baseada em serviços instanciados no `main.ts` e injetados nas Views.

- **Frontend**: `CompanionView` (HTML/DOM manipulado diretamente).
- **Backend (Plugin)**: Serviços TypeScript puros localizados em `src/services` e `src/analyzers`.
- **Gateway**: Abstração para comunicação com LLMs em `src/gateway`.

---

## 2. Serviços Principais (`src/services`)

### `AnalysisService`

O orquestrador central de todas as análises de texto estáticas (não-LLM).

- **Função**: Recebe o texto bruto, executa todos os analisadores registrados e retorna um objeto `FullAnalysis`.
- **Uso**: Chamado automaticamente (com debounce) ou manualmente pela `CompanionView`.
- **Dependências**: `StatisticsAnalyzer`, `ReadabilityAnalyzer`, `StyleAnalyzer`, `FictionAnalyzer`.

### `PersonaService`

Gerencia a avaliação subjetiva do texto baseada em "Personas" simuladas por IA.

- **Função**: `evaluate(text, personaId)` envia o texto para o LLM com um System Prompt específico.
- **Personas Disponíveis**:
  - `booktuber`: Foca em entretenimento, ritmo e "vibes".
  - `hardcore`: Foca em consistência, worldbuilding e lógica.
  - `casual`: Foca em clareza, simplicidade e diversão rápida.
- **Retorno**: JSON estruturado com rating (1-5), pontos fortes/fracos e feedback narrativo.

### `CleanupService`

(Em desenvolvimento) Utilitários para limpeza de texto antes da análise.

- **Função**: Remover frontmatter, comentários do Obsidian, e normalizar quebras de linha.

---

## 3. Analisadores (`src/analyzers`)

Componentes puros que processam string e retornam métricas. Não dependem da UI.

### `StatisticsAnalyzer`

Métricas quantitativas básicas.

- **Métricas**:
  - Contagem de Palavras, Caracteres (c/s espaços).
  - Frases e Parágrafos.
  - Tempo de Leitura (baseado em WPM configurável, padrão 200).
  - Densidade de Palavras-chave (ignora stop words).

### `ReadabilityAnalyzer`

Calcula índices de legibilidade (fórmulas padrão da indústria).

- **Fórmulas**:
  - **Flesch-Kincaid Grade**: Nível escolar (EUA).
  - **Flesch Reading Ease**: 0-100 (quanto maior, mais fácil).
  - **Gunning Fog**: Complexidade textual.
  - **SMOG Index**: Anos de educação necessários.
  - **Coleman-Liau**: Baseado em caracteres/frase.
  - **ARI (Automated Readability Index)**.

### `StyleAnalyzer`

Verifica vícios de linguagem e estilo.

- **Detecções**:
  - **Voz Passiva**: Identifica construções de ser/estar + particípio.
  - **Advérbios**: Conta palavras terminadas em "mente" (e sufixos ingleses `ly` se configurado).
  - **Frases Longas**: Identifica frases com mais de X palavras (configurável).

### `FictionAnalyzer`

Métricas específicas para narrativa de ficção.

- **Métricas**:
  - **Equilíbrio Diálogo vs Narrativa**: Porcentagem do texto dentro de aspas.
  - **Variação de Ritmo**: Média de comprimento de frases por parágrafo (identifica "muros de texto" ou "staccato" excessivo).

---

## 4. Gateway de IA (`src/gateway`)

### `LLMGateway`

Classe unificadora para chamadas a APIs de IA. Suporta fallback e verificação de conexão.

- **Provedores Suportados (Drivers)**:
  1.  **Ollama (Local)**:
      - Rota: `/api/generate`
      - Ideal para privacidade e uso offline.
      - Modelo configurável (ex: `mistral`, `llama3`).
  2.  **Google Gemini (Cloud)**:
      - Rota: `generativelanguage.googleapis.com`
      - Requer API Key.
      - Modelo: `gemini-pro`.
- **Métodos**:
  - `checkConnection()`: Ping para verificar disponibilidade.
  - `complete(prompt, options)`: Gera texto ou JSON (se instruído no prompt).

---

## 5. View (`src/views`)

### `CompanionView`

A interface lateral do Obsidian.

- **Renderização**: Manipulação direta do DOM (Vanilla JS wrapper em uma classe Obsidian `ItemView`).
- **Reatividade**:
  - `debouncedAnalyze`: Atrasa a análise em 1s após a digitação.
  - **Meters e Cores**: Atualiza classes CSS (`swc-meter__fill--good`, `--bad`) dinamicamente baseada nos thresholds definidos nos Settings.

# Funcionalidades Mapeadas

Documento de referência com as funcionalidades mapeadas para o SmartWriting Companion.

## 1. Infra e Configuração

- Setup inicial do plugin Obsidian (main.ts, manifest.json) — Implementado
- Definição de interfaces e tipos (TypeScript) — Implementado
- Sistema de Configurações (SettingsTab) — Presente (UI temporariamente vazia)
- Arquitetura de serviços (Services, Analyzers, Gateway) — Implementado (esqueleto + integração básica)

## 2. Analisadores (Core Logic)

- `StatisticsAnalyzer` (Palavras, tempo de leitura) — Implementado
- `ReadabilityAnalyzer` (Flesch-Kincaid, sílabas) — Implementado
- `StyleAnalyzer` (Voz passiva, advérbios, filter words) — Implementado
- `FictionAnalyzer` (Diálogo vs Narrativa) — Implementado
- `TextCleanup` (Lógica de regex para limpeza) — Implementado (via `CleanupService`)

## 3. Inteligência Artificial (LLM)

- `LLMGateway` (Abstração de provedores) — Implementado (integração básica)
- Integração com Ollama (Local) — Implementado (configurável)
- Integração com Google Gemini (Nuvem) — Integrado (chaves configuráveis)
- `PersonaService` (Prompts e engenharia de personas) — Implementado (serviço de prompts)

## 4. Interface (UI/UX)

- `CompanionView` (Estrutura HTML/DOM) — Implementado
- Integração da View com os Serviços (Dados reais) — Implementado (via `AnalysisService`)
- Estilização CSS (`styles/main.css`, `styles/tokens.css`) — Implementado
- Ícone na barra de título (Header Action) — Em progresso (SVG atualizado, substituição forçada necessária)
- Visualização de métricas com barras de progresso e cores semânticas — Implementado (UI estática para métricas)

## 5. Polimento e Extras

- `SuggestionDecorations` (Grifos no editor via CodeMirror) — Pendente (primeira funcionalidade a implementar)
- Testes unitários abrangentes — Pendente
- Tradução/i18n — Pendente

## Observações

- A `SettingsTab` foi temporariamente esvaziada para evitar execução de funções até implementarmos as opções de forma incremental.
- Automatização de release local criada (`scripts/bump-and-deploy.js`) e comando `npm run release:local` disponível.

## Próxima funcionalidade a implementar

- `SuggestionDecorations` — destacar problemas de estilo no editor (voz passiva, advérbios em excesso, frases longas). Discutir comportamento e UX antes de implementar.

### `StatisticsAnalyzer` — Plano de implementação inicial

- O que irá medir:

  - Contagem de palavras
  - Contagem de caracteres (com e sem espaços)
  - Número de parágrafos e frases
  - Tempo estimado de leitura (minutos) com base em WPM configurável (padrão 200 WPM)
  - Densidade de palavras-chave / termos (frequência por 1k palavras)

- Metodologia:

  - Tokenizar o texto em frases e palavras usando regex simples e heurísticas robustas para Markdown (ignorar frontmatter quando presente).
  - Estimar tempo de leitura como `Math.ceil(words / wpm)`.
  - Calcular densidades contando ocorrências normalizadas (lowercase, stripping punctuation) e reportar por 1000 palavras.
  - Expor uma API síncrona leve (por exemplo, `analyze(text: string): StatisticsResult`) que devolve um POJO com todas as métricas.

- Bibliotecas a usar (open-source / gratuitas):

  - `syllable` (já presente nas dependências) — para contagem de sílabas quando necessário para métricas futuras.
  - nenhuma outra dependência necessária para a versão inicial; usar utilitários internos (regex, String methods) para garantir leveza e compatibilidade com o bundler.

  - Observação: se precisarmos de tokenização mais robusta no futuro, considerar `wink-tokenizer` ou `nlp.js` como opções, mas evitar aumentar o bundle inicialmente.

# Plano de Testes Sistêmico e Automático - SmartWriting Companion

Este documento detalha a estratégia de testes para garantir a robustez das funcionalidades mapeadas.

## 1. Estratégia de Testes

O projeto adotará uma abordagem de pirâmide de testes:

1.  **Testes Unitários (Jest)**: O foco principal. Validar a lógica pura dos Analisadores (`src/analyzers`).
2.  **Testes de Integração (Mocked)**: Validar a comunicação entre `AnalysisService` e os analisadores, e `LLMGateway` com mocks.
3.  **Testes Manuais/E2E (Obsidian)**: Validação visual e funcional dentro do ambiente do Obsidian.

---

## 2. Testes Unitários (Automáticos)

Framework sugerido: **Jest** (Standard para TypeScript) ou `ts-node` simples para scripts de verificação rápida.

### 2.1. `StatisticsAnalyzer`

- [ ] **Caso: Texto Vazio**: Garantir retorno zero/seguro.
- [ ] **Caso: Texto Simples**: "O gato subiu." -> 3 palavras, 14 caracteres, 1 frase.
- [ ] **Caso: Múltiplos Parágrafos**: Verificar contagem correta de quebras de linha duplas.
- [ ] **Caso: Tempo de Leitura**: Validar cálculo `ceil(words / 200)`.

### 2.2. `ReadabilityAnalyzer`

- [ ] **Caso: Frases Curtas**: Validar índice Flesch alto (Fácil).
- [ ] **Caso: Acadêmico/Técnico**: Validar índice Flesch baixo (Difícil).
- [ ] **Caso: Sílabas (Edge cases)**: Palavras complexas vs monossílabas (verificar precisão da biblioteca `syllable` ou heurística interna).

### 2.3. `StyleAnalyzer`

- [ ] **Caso: Voz Passiva**:
  - "O bolo foi comido por mim." (Detectar)
  - "Eu comi o bolo." (Não detectar)
- [ ] **Caso: Advérbios**:
  - "Ele correu rapidamente." (Detectar)
  - "Mente sã." (Não detectar falso positivo se possível, ou documentar limitação).
- [ ] **Caso: Frases Longas**: Input com > 40 palavras sem pontuação terminal.

### 2.4. `FictionAnalyzer`

- [ ] **Caso: Diálogo Puro**: Texto 100% entre aspas -> 100% Diálogo.
- [ ] **Caso: Misto**: 50% aspas, 50% fora.

---

## 3. Testes de Integração / Serviços

### 3.1. `AnalysisService`

- [ ] **Pipeline**: Enviar input e verificar se `FullAnalysis` contém chaves populadas de todos os 4 analisadores.
- [ ] **Performance**: Enviar texto de 100k palavras e medir tempo de execução (Benchmark < 200ms desejado).

### 3.2. `PersonaService` & `LLMGateway` (Mocked)

- [ ] **Mocked Success**: Simular resposta JSON válida do Ollama. Verificar se `PersonaService.evaluate` faz o parse correto.
- [ ] **Mocked Failure**: Simular timeout/erro 500 do Ollama. Verificar se `evaluate` lança erro tratado.
- [ ] **JSON Malformado**: Simular LLM retornando texto plano misturado com JSON. Validar regex de limpeza.

---

## 4. Testes do Sistema (Manuais no Obsidian)

### 4.1. Instalação e Load

- [ ] Ativar plugin nas configurações.
- [ ] Verificar se Ícone aparece na Ribbon e Header.
- [ ] Verificar se `CompanionView` abre na sidebar direita.

### 4.2. Fluxo de Análise

- [ ] Abrir nota Markdown.
- [ ] Digitar texto.
- [ ] Clicar "Analisar Agora" (ou aguardar debounce se auto-on).
- [ ] Verificar atualização dos números na Sidebar.
- [ ] Trocar de arquivo ativo -> Verificar se Sidebar limpa ou atualiza para novo arquivo.

### 4.3. Configurações

- [ ] Alterar "WPM" em Settings. -> Re-analisar -> Tempo de leitura mudou?
- [ ] Alterar "Ollama Model". -> Avaliação de Persona usa novo modelo?

---

## 5. Ferramental Necessário

Para implementar a suíte de testes automáticos:

1.  Instalar `jest`, `ts-jest`, `@types/jest`.
2.  Configurar `jest.config.js` para suportar imports ES6/TypeScript.
3.  Criar pasta `__tests__` ou `src/analyzers/__tests__`.

```bash
npm install --save-dev jest ts-jest @types/jest
npx ts-jest config:init
```

import { ReadabilityMetrics } from '../types';

/**
 * Smart Writing Companion - Readability Analyzer
 * Calculates several readability metrics locally for PT/EN.
 */
type Lang = 'pt' | 'en';

interface TextStats {
    words: number;
    sentences: number;
    syllables: number;
    characters: number;
    letters: number;
    complexWords: number;
    polysyllables: number;
    wordList: string[];
}

export class ReadabilityAnalyzer {
    analyze(text: string): ReadabilityMetrics {
        const stats = this.getTextStats(text);

        if (stats.words === 0 || stats.sentences === 0) {
            return {
                fleschKincaid: 0,
                fleschReadingEase: 0,
                gunningFog: 0,
                colemanLiau: 0,
                automatedReadability: 0,
                smog: 0,
                daleChall: 0,
            };
        }

        const fk = this.fleschKincaidGrade(stats);
        const fre = this.fleschReadingEase(stats);
        const gf = this.gunningFog(stats);
        const cli = this.colemanLiauIndex(stats);
        const ari = this.automatedReadabilityIndex(stats);
        const smog = this.smogIndex(stats);
        const dale = this.estimateDaleChall(stats);

        return {
            fleschKincaid: fk,
            fleschReadingEase: fre,
            gunningFog: gf,
            colemanLiau: cli,
            automatedReadability: ari,
            smog: smog,
            daleChall: dale,
        };
    }

    // Simple Dale-Chall proxy using complexWords as difficult words proxy
    private estimateDaleChall(s: TextStats): number {
        const difficultPercent = (s.complexWords / Math.max(1, s.words)) * 100;
        let score = 0.1579 * difficultPercent + 0.0496 * (s.words / Math.max(1, s.sentences));
        if (difficultPercent > 5) score += 3.6365;
        return Math.round(score * 10) / 10;
    }

    // ===== Text stats extraction =====
    private getTextStats(text: string): TextStats {
        const cleaned = this.stripReferences(this.cleanText(text));

        const sentences = this.getSentences(cleaned);
        const wordList = this.getWords(cleaned);
        const words = wordList.length;
        const characters = cleaned.replace(/\s+/g, '').length;
        const letters = (cleaned.match(/[\p{L}]/gu) || []).length;

        let syllables = 0;
        for (const w of wordList) syllables += this.countSyllables(w);

        const polysyllables = wordList.filter(w => this.countSyllables(w) >= 3).length;

        // complexWords: try to exclude some suffixes and hyphenated compounds
        const complexWords = wordList.filter(w => this.isComplexWord(w)).length;

        return {
            words,
            sentences: sentences.length,
            syllables,
            characters,
            letters,
            complexWords,
            polysyllables,
            wordList,
        };
    }

    // ===== Formulas =====
    private fleschKincaidGrade(s: TextStats): number {
        const wordsPerSentence = s.words / Math.max(1, s.sentences);
        const syllablesPerWord = s.syllables / Math.max(1, s.words);
        const raw = 0.39 * wordsPerSentence + 11.8 * syllablesPerWord - 15.59;
        return Math.max(0, Math.round(raw * 10) / 10);
    }

    private fleschReadingEase(s: TextStats): number {
        const wordsPerSentence = s.words / Math.max(1, s.sentences);
        const syllablesPerWord = s.syllables / Math.max(1, s.words);
        const raw = 206.835 - 1.015 * wordsPerSentence - 84.6 * syllablesPerWord;
        return Math.round(raw * 10) / 10;
    }

    private gunningFog(s: TextStats): number {
        const wordsPerSentence = s.words / Math.max(1, s.sentences);
        const complexRatio = (s.complexWords / Math.max(1, s.words)) * 100;
        const raw = 0.4 * (wordsPerSentence + complexRatio);
        return Math.round(raw * 10) / 10;
    }

    private colemanLiauIndex(s: TextStats): number {
        const L = (s.letters / Math.max(1, s.words)) * 100;
        const S = (s.sentences / Math.max(1, s.words)) * 100;
        const raw = 0.0588 * L - 0.296 * S - 15.8;
        return Math.max(0, Math.round(raw * 10) / 10);
    }

    private automatedReadabilityIndex(s: TextStats): number {
        const raw = 4.71 * (s.characters / Math.max(1, s.words)) + 0.5 * (s.words / Math.max(1, s.sentences)) - 21.43;
        return Math.max(0, Math.round(raw * 10) / 10);
    }

    private smogIndex(s: TextStats): number {
        // SMOG requires at least 3 sentences; for <30 sentences we scale polysyllables
        if (s.sentences === 0) return 0;
        const pol = s.polysyllables;
        const scale = s.sentences < 30 ? (30 / s.sentences) : 1;
        const adjusted = pol * scale;
        const raw = 1.0430 * Math.sqrt(adjusted * (30 / Math.max(1, s.sentences))) + 3.1291;
        return Math.round(raw * 10) / 10;
    }

    // ===== Utilities =====
    private detectLanguage(text: string): Lang {
        // If text contains Portuguese diacritics, assume PT; otherwise EN
        if (/[áéíóúâêôãõàçíúüÁÉÍÓÚÂÊÔÃÕÀÇ]/.test(text)) return 'pt';
        return 'en';
    }

    private cleanText(text: string): string {
        return text
            .replace(/```[\s\S]*?```/g, '')
            .replace(/`[^`]+`/g, '')
            .replace(/^#{1,6}\s+/gm, '')
            .replace(/\*\*([^*]+)\*\*/g, '$1')
            .replace(/\*([^*]+)\*/g, '$1')
            .replace(/__([^_]+)__/g, '$1')
            .replace(/_([^_]+)_/g, '$1')
            .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
            .replace(/!\[[^\]]*\]\([^)]+\)/g, '')
            .replace(/^>\s+/gm, '')
            .replace(/^[\s]*[-*+]\s+/gm, '')
            .replace(/^[\s]*\d+\.\s+/gm, '')
            .replace(/[“”«»]/g, '"')
            .replace(/[‘’]/g, "'")
            .trim();
    }

    // remove trailing references/works cited blocks
    private stripReferences(text: string): string {
        let without = text.replace(/\n#{1,6}\s*(works\s*cited|references|referências)[\s\S]*$/i, '');
        without = without.replace(/https?:\/\/[^\s)]+/gi, '');
        without = without.replace(/www\.[^\s)]+/gi, '');
        without = without.replace(/(^|\s)\d{3,}(?=\s|$)/g, '');
        // remove 'accessed Month Day, Year' and similar date fragments
        without = without.replace(/accessed\s+[A-Za-z]+\s+\d{1,2},?\s*\d{4}/gi, '');
        // remove standalone month names that often appear in references
        without = without.replace(/\b(January|February|March|April|May|June|July|August|September|October|November|December|Janeiro|Fevereiro|Março|Abril|Maio|Junho|Julho|Agosto|Setembro|Outubro|Novembro|Dezembro)\b/gi, '');
        return without;
    }

    private getWords(text: string): string[] {
        const words = text.match(/[\p{L}\p{N}'’-]+/gu) || [];
        return (words as string[])
            .map(w => w.replace(/^['’”"]+|['’”"]+$/g, ''))
            .filter(w => /\p{L}/u.test(w) && !/^https?:/i.test(w) && !/^www\./i.test(w));
    }

    private getSentences(text: string): string[] {
        // Split on sentence enders, keep minimal fragments
        const matches = text.match(/[^.!?]+[.!?]+(\s|$)|[^.!?]+$/g) || [];
        return matches.map(s => s.trim()).filter(s => s.length > 0);
    }

    private countSyllables(wordRaw: string): number {
        const word = wordRaw.toLowerCase().replace(/[^\p{L}\p{N}'’-]/gu, '');
        if (!word) return 0;

        // Detect language by diacritics heuristic
        const lang = this.detectLanguage(word);
        if (lang === 'pt') return this.countSyllablesPT(word);
        return this.countSyllablesEN(word);
    }

    private countSyllablesPT(word: string): number {
        // Portuguese vowels including accents
        const cleaned = word.normalize('NFC');
        if (cleaned.length <= 3) return 1;
        const matches = cleaned.match(/[aeiouáéíóúâêîôûãõàèìòù]+/gi);
        return Math.max(1, matches ? matches.length : 1);
    }

    private countSyllablesEN(word: string): number {
        // Heuristic for English
        const w = word.toLowerCase();
        if (w.length <= 3) return 1;
        // count vowel groups
        let matches = w.match(/[aeiouy]+/g);
        let count = matches ? matches.length : 0;
        // subtract silent 'e'
        if (w.endsWith('e')) {
            // exceptions: 'le' endings where preceding letter is consonant (e.g., 'bottle')
            if (!(w.endsWith('le') && w.length > 2 && !/[aeiouy]/.test(w[w.length - 3]))) {
                count = Math.max(1, count - 1);
            }
        }
        // add for -le if not counted
        if (w.endsWith('le') && w.length > 2 && !/[aeiouy]/.test(w[w.length - 3])) {
            count += 1;
        }
        return Math.max(1, count);
    }

    private isComplexWord(word: string): boolean {
        const original = word;
        // Normalize
        word = word.replace(/^['"“”‘’]+|['"“”‘’]+$/g, '');

        // Hyphenated: consider any part complex
        if (word.includes('-')) {
            return word.split('-').some(part => this.countSyllables(part) >= 3);
        }

        // Exclude obvious proper nouns (starts with uppercase and not sentence start heuristics)
        if (/^[A-ZÀ-ÖØ-Ý][a-zà-öø-ÿ]+$/.test(original)) return false;

        // very short words cannot be complex
        if (word.length <= 3) return false;

        // Small whitelist of common short words in PT/EN that may look polysyllabic
        const whitelist = new Set(['international','information','government','comunidade','nacional','identidade']);
        if (whitelist.has(word.toLowerCase())) return false;

        // Strip common suffixes that may inflate syllable counts but not necessarily complexity
        const stripped = word.replace(/(mente|mente\b|ação|acao|ção|cao|tion|sion|ing|ed|es|ais|ais\b)$/i, '');

        return this.countSyllables(stripped) >= 3;
    }

    // ===== Descriptions =====
    public getGradeDescription(fleschKincaid: number): string {
        if (fleschKincaid < 1) return 'Kindergarten';
        if (fleschKincaid < 5) return 'Elementary School';
        if (fleschKincaid < 9) return 'Middle School';
        if (fleschKincaid < 13) return 'High School';
        return 'College Level';
    }

    public getEaseDescription(fleschEase: number): string {
        if (fleschEase >= 90) return 'Very Easy';
        if (fleschEase >= 60) return 'Standard';
        if (fleschEase >= 30) return 'Difficult';
        return 'Very Difficult';
    }

    public isWithinFictionTarget(metrics: ReadabilityMetrics): boolean {
        return metrics.fleschKincaid >= 7 && metrics.fleschKincaid <= 9;
    }
}


import { DocumentStats } from '../types';

export interface StatisticsOptions {
    wpm?: number;
    keywords?: string[];
}

/**
 * Calculates basic document statistics (100% local, zero dependencies)
 */
export class StatisticsAnalyzer {
    analyze(text: string, options: StatisticsOptions = {}): DocumentStats {
        const cleanText = this.stripFrontmatter(text);

        // Normalize for counting: strip Markdown so tokenization matches how we count words
        const mdClean = this.stripMarkdown(cleanText);
        // Unicode-aware tokens: letters, numbers, apostrophes and hyphens
        let tokens = (mdClean.match(/[\p{L}\p{N}'’\-]+/gu) || []).map(t => t.replace(/^['’"“”]+|['’"“”]+$/g, ''));
        // Filter out tokens that are purely numeric or URL fragments (http/www) or punctuation-only
        tokens = tokens.filter(t => /\p{L}/u.test(t) && !/^https?:/i.test(t) && !/^www\./i.test(t));
        const words = tokens.length;
        const sentences = this.countSentences(cleanText);
        const paragraphs = this.countParagraphs(cleanText);
        const characters = cleanText.length;
        const charactersNoSpaces = cleanText.replace(/\s/g, '').length;
        const wpm = options.wpm || 200;
        const readingTimeMinutes = this.calculateReadingTime(words, wpm);

        const result: DocumentStats = {
            words,
            characters,
            charactersNoSpaces,
            sentences,
            paragraphs,
            readingTimeMinutes,
            // wordsPer1000 as integer (per 1000 words)
            wordsPer1000: words > 0 ? Math.floor(words / 1000) : 0,
            keywordDensityPer1000: {}
        };

        if (options.keywords && options.keywords.length > 0 && words > 0) {
            // Use token array for robust, Unicode-aware counting so denominador/nominal align
            const lcTokens = tokens.map(t => t.toLowerCase());
            for (const kw of options.keywords) {
                const kwLower = kw.toLowerCase();
                // Count exact token matches (handles punctuation/hyphens consistently)
                const matchesCount = lcTokens.reduce((c, tok) => c + (tok === kwLower ? 1 : 0), 0);
                result.keywordDensityPer1000![kw] = Math.round((matchesCount / words) * 1000 * 10) / 10;
            }
        }

        return result;
    }

    private countWords(text: string): number {
        // Strip markdown before counting
        const cleanText = this.stripMarkdown(text);
        if (!cleanText.trim()) return 0;
        
        // Count words, handling contractions and hyphenated words
        // This regex matches words including those with apostrophes or internal hyphens
        // \p{L} matches any unicode letter
        return (cleanText.match(/[\p{L}\p{N}'’-]+/gu) || []).length;
    }

    private countSentences(text: string): number {
        const cleanText = this.stripMarkdown(text);
        if (!cleanText.trim()) return 0;

        // Basic sentence splitting, but ignoring common abbreviations
        // This is a simplified approach; a robust solution might need a better tokenizer
        // matches . ? or ! followed by space or end of string
        const sentences = cleanText.split(/[.?!]+(\s|$)/).filter(s => s.trim().length > 0);
        return sentences.length;
    }

    private countParagraphs(text: string): number {
        // Obsidian style: split by double newline
        return text.split(/\n\s*\n/).filter(p => p.trim().length > 0).length;
    }

    private calculateReadingTime(words: number, wpm: number = 200): number {
        // return decimal minutes with one decimal place
        const mins = words / Math.max(1, wpm);
        return Math.round(mins * 10) / 10;
    }

    private stripFrontmatter(text: string): string {
        return text.replace(/^---\n[\s\S]*?\n---\n/, '');
    }

    private stripMarkdown(text: string): string {
        // Simple markdown stripper
            const clean = text
            // Headers
            .replace(/^#+\s+/gm, '')
            // Bold/Italic
                .replace(/(\*\*|__)(.*?)\1/g, '$2')
                .replace(/(\*|_)(.*?)\1/g, '$2')
            // Links
            .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
            // Images
            .replace(/!\[([^\]]*)\]\([^)]+\)/g, '')
            // Blockquotes
            .replace(/^>\s+/gm, '')
            // Code blocks
            .replace(/```[\s\S]*?```/g, '')
            .replace(/`([^`]+)`/g, '$1');

        // Strip trailing bibliography/works cited or references sections if present
        let withoutRefs = clean.replace(/\n#{1,6}\s*(works\s*cited|references|referências)[\s\S]*$/i, '');
        // remove bare URLs
        withoutRefs = withoutRefs.replace(/https?:\/\/[^\s)]+/gi, '');
        withoutRefs = withoutRefs.replace(/www\.[^\s)]+/gi, '');
        // remove isolated long numbers/years and numeric lists that come from references
        withoutRefs = withoutRefs.replace(/(^|\s)\d{3,}(?=\s|$)/g, '');
        // remove 'accessed Month Day, Year' and similar date fragments
        withoutRefs = withoutRefs.replace(/accessed\s+[A-Za-z]+\s+\d{1,2},?\s*\d{4}/gi, '');
        // remove standalone month names that often appear in references
        withoutRefs = withoutRefs.replace(/\b(January|February|March|April|May|June|July|August|September|October|November|December|Janeiro|Fevereiro|Março|Abril|Maio|Junho|Julho|Agosto|Setembro|Outubro|Novembro|Dezembro)\b/gi, '');
        return withoutRefs;
    }
}

export const ICON_SVG = `<?xml version="1.0" encoding="UTF-8"?>
<svg id="Layer_1" xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 100 100">
  <defs>
    <style>
      .st0 {
        stroke-width: 11.8px;
      }

      .st0, .st1, .st2 {
        fill: none;
        stroke: #000;
        stroke-linecap: round;
        stroke-linejoin: round;
      }

      .st1 {
        stroke-width: 7.8px;
      }

      .st2 {
        stroke-width: 8.3px;
      }
    </style>
  </defs>
  <path class="st0" d="M12.5,88.3h75"/>
  <path class="st1" d="M74,9.4c3.4-3.1,8.8-3.1,12.2,0s3.4,8.1,0,11.1l-50.7,46.4-16.2,3.7,4.1-14.9L74,9.4Z"/>
  <path class="st2" d="M15.1,10.1l4.2,8.3-4.2,8.3-4.2-8.3,4.2-8.3Z"/>
</svg>`;

export const ICON_DATA_URL = 'data:image/svg+xml;utf8,' + encodeURIComponent(ICON_SVG);

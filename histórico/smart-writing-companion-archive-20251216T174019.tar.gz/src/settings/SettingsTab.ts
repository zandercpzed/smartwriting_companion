import { App, PluginSettingTab, Setting } from 'obsidian';
import SmartWritingCompanion from '../../main';

export class SWCSettingTab extends PluginSettingTab {
    plugin: SmartWritingCompanion;

    constructor(app: App, plugin: SmartWritingCompanion) {
        super(app, plugin);
        this.plugin = plugin;
    }

    display(): void {
        const { containerEl } = this;
        containerEl.empty();
        // Intentionally left blank — settings will be added incrementally.
    }
}

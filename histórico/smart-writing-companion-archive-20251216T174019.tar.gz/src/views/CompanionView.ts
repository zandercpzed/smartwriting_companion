import { ItemView, WorkspaceLeaf, TFile, Debouncer, debounce, Notice } from 'obsidian';
import type SmartWritingCompanion from '../../main';
import { ICON_DATA_URL, ICON_SVG } from '../assets/icon-text-companion-sparkle';
import { FullAnalysis } from '../types';

export const VIEW_TYPE_COMPANION = "smart-writing-companion-view";

/**
 * The main UI component for the SmartWriting Companion.
 * It renders a sidebar view that displays analysis metrics and actions.
 * Updates are reactive based on the active file content.
 */
export class CompanionView extends ItemView {
    plugin: SmartWritingCompanion;
    private debouncedAnalyze: (text: string) => void;

	constructor(leaf: WorkspaceLeaf, plugin: SmartWritingCompanion) {
		super(leaf);
        this.plugin = plugin;
        this.debouncedAnalyze = debounce((text: string) => this.runAnalysis(text), 1000, true);
	}

	getViewType() {
		return VIEW_TYPE_COMPANION;
	}

	getDisplayText() {
		return "SmartWriting Companion";
	}

    async onOpen() {
        const container = this.containerEl;
        container.empty();
        this.renderInitial(container);
        // Do not register automatic analysis events. User must click 'Analisar Agora'.
    }

    renderInitial(container: HTMLElement) {

        container.innerHTML = `
    <div class="sidebar-wrapper">
        <aside class="sidebar">
            <div class="swc-companion">
                
                <!-- HEADER -->
                <header class="swc-header">
                    <div class="swc-header__left">
                        <span class="swc-header__icon"><img class="swc-header__icon-img" alt="icon"/></span>
                        <h1 class="swc-header__title">Smart Writing</h1>
                    </div>
                    <div class="swc-header__right">
                        <button id="swc-open-settings" class="swc-icon-button" title="Configurações">⚙️</button>
                    </div>
                </header>
                <!-- ACTION GRID (single button) -->
                <div class="swc-actions swc-actions--top">
                    <div class="swc-actions__grid">
                        <button id="swc-analyze-now" class="swc-action-btn swc-action-btn--primary swc-action-btn--full">
                            <span class="swc-action-btn__icon">🔍</span>
                            <span>Analisar Agora</span>
                        </button>
                    </div>
                </div>

                <!-- STATS -->
                <div class="swc-document-card">
                    <div class="swc-document-card__filename"><strong>Estatísticas</strong></div>
                    <div class="swc-document-card__stats">
                        <div>Palavras: <span class="swc-stats-words">-</span></div>
                        <div>Tempo leitura (min): <span class="swc-stats-reading">-</span></div>
                        <div>Palavras por 1000: <span class="swc-stats-wp1000">-</span></div>
                        <div class="swc-stats-keywords">Palavras-chave: <span>-</span></div>
                    </div>
                </div>

            </div>
        </aside>
    </div>
        `;

        // Header toggles (none right now, but keep for future)
        this.containerEl.querySelectorAll('.swc-section__header').forEach(el => {
            el.addEventListener('click', () => {
                const sectionId = (el as HTMLElement).getAttribute('data-section');
                if (sectionId) {
                    const section = this.containerEl.querySelector(`#${sectionId}`);
                    if (section) {
                        section.classList.toggle('swc-section--collapsed');
                    }
                }
            });
        });

        // Inline SVG icon into header
        const iconContainer = this.containerEl.querySelector('.swc-header__icon') as HTMLElement;
        if (iconContainer) {
            try { iconContainer.innerHTML = ICON_SVG; } catch (e) {}
        }

        // Settings button: open Obsidian settings (fallback Notice)
        const settingsButton = this.containerEl.querySelector('#swc-open-settings');
        if (settingsButton) {
            settingsButton.addEventListener('click', async () => {
                try {
                    if (this.plugin && typeof (this.plugin as any).openAndFocusSettings === 'function') {
                        await (this.plugin as any).openAndFocusSettings();
                        return;
                    }
                } catch (e) {
                    // fall through to notice
                }
                new Notice('Abra as configurações do Obsidian e busque por SmartWriting Companion');
            });
        }

        // Attach analyze button behavior: do not auto-run analysis.
        const analyzeBtn = this.containerEl.querySelector('#swc-analyze-now');
        if (analyzeBtn) {
            analyzeBtn.addEventListener('click', async () => {
                const file = this.app.workspace.getActiveFile();
                if (file && (file.extension === 'md' || file.extension === 'txt')) {
                    const content = await this.app.vault.read(file);
                    this.updateDocumentInfo(file);
                    this.runAnalysis(content);
                } else {
                    // clear or show message — for now we just clear existing UI
                    this.containerEl.querySelectorAll('.swc-readability-value, .swc-metric__value, .swc-meter__value').forEach(el => (el as HTMLElement).textContent = '-');
                    new Notice('Nenhum arquivo Markdown/TXT ativo para analisar');
                }
            });
        }
	}

    async checkActiveFile() {
        const file = this.app.workspace.getActiveFile();
        if (file instanceof TFile && (file.extension === 'md' || file.extension === 'txt')) {
             const content = await this.app.vault.read(file);
             this.updateDocumentInfo(file);
             this.runAnalysis(content);
        }
    }
    
    updateDocumentInfo(file: TFile) {
        const nameEl = this.containerEl.querySelector('.swc-document-card__filename span:nth-child(2)');
        if (nameEl) nameEl.textContent = file.name;
    }

    async runAnalysis(text: string) {
        if (!text) return;
        
        // Run analysis via service
        const results: FullAnalysis = this.plugin.analysisService.analyze(text);
        
        this.updateUI(results);
    }
    
    /**
     * Updates the DOM elements with the results of a full analysis.
     * Manages meter widths, colors (good/bad thresholds), and text values.
     * @param results - The complete analysis result object.
     */
    updateUI(results: FullAnalysis) {
        // Update Stats: update child spans directly so we don't clobber structure
        const wordsEl = this.containerEl.querySelector('.swc-stats-words');
        const readingEl = this.containerEl.querySelector('.swc-stats-reading');
        const wp1000El = this.containerEl.querySelector('.swc-stats-wp1000');
        const kwInnerEl = this.containerEl.querySelector('.swc-stats-keywords span');

        if (wordsEl) (wordsEl as HTMLElement).textContent = results.stats.words.toLocaleString();
        if (readingEl) (readingEl as HTMLElement).textContent = String(Math.round(results.stats.readingTimeMinutes ?? 0));
        if (wp1000El) {
            const wp = results.stats.wordsPer1000;
            (wp1000El as HTMLElement).textContent = (typeof wp === 'number') ? wp.toFixed(0) : '-';
        }
        if (kwInnerEl) {
            const kd = results.stats.keywordDensityPer1000 || {};
            const items = Object.keys(kd).map(k => `${k}: ${kd[k]}‰`);
            (kwInnerEl as HTMLElement).textContent = items.length ? items.join(', ') : '-';
        }
        
        // Update Readability
        const fkValue = this.containerEl.querySelector('.swc-readability__fk-value');
        const fkFill = this.containerEl.querySelector('.swc-inline-meter__fill') as HTMLElement;
        if (fkValue) fkValue.textContent = results.readability.fleschKincaid.toString();
        if (fkFill) {
            const fk = results.readability.fleschKincaid;
            const percent = Math.round(100 * (1 / (1 + Math.exp(- (fk - 8) / 3))));
            fkFill.style.width = `${percent}%`;

            // Color coding using same classes as main meter
            fkFill.className = 'swc-inline-meter__fill'; // reset
            if (fk >= 7 && fk <= 9) {
                fkFill.classList.add('swc-meter__fill--good');
            } else if (fk < 5 || fk > 12) {
                fkFill.classList.add('swc-meter__fill--bad');
            } else {
                fkFill.classList.add('swc-meter__fill--ok');
            }

            // Populate tooltip with raw metrics
            const tooltip = this.containerEl.querySelector('.swc-meter__tooltip');
            if (tooltip) {
                tooltip.textContent = `Flesch ${results.readability.fleschKincaid}, F-Read ${results.readability.fleschReadingEase}, Gunning ${results.readability.gunningFog}, SMOG ${results.readability.smog}`;
                const parent = fkFill.parentElement;
                if (parent) {
                    parent.addEventListener('mouseenter', () => { if (tooltip) (tooltip as HTMLElement).style.display = 'block'; });
                    parent.addEventListener('mouseleave', () => { if (tooltip) (tooltip as HTMLElement).style.display = 'none'; });
                }
            }
        }
        // Populate per-metric fields
        const freEl = this.containerEl.querySelector('.swc-readability__fre');
        const gunningEl = this.containerEl.querySelector('.swc-readability__gunning');
        const smogEl = this.containerEl.querySelector('.swc-readability__smog');
        const cliEl = this.containerEl.querySelector('.swc-readability__cli');
        const ariEl = this.containerEl.querySelector('.swc-readability__ari');
        const daleEl = this.containerEl.querySelector('.swc-readability__dale');
        if (freEl) freEl.textContent = String(results.readability.fleschReadingEase);
        if (gunningEl) gunningEl.textContent = String(results.readability.gunningFog);
        if (smogEl) smogEl.textContent = String(results.readability.smog);
        if (cliEl) cliEl.textContent = String(results.readability.colemanLiau);
        if (ariEl) ariEl.textContent = String(results.readability.automatedReadability);
        if (daleEl) daleEl.textContent = String((results.readability as any).daleChall ?? '-');
        
        // Update Metrics
        const passiveStatus = results.style.passiveVoicePercent > this.plugin.settings.analysis.maxPassiveVoicePercent ? 'bad' : 'good';
        this.updateMetric('Voz passiva', `${results.style.passiveVoicePercent.toFixed(1)}%`, passiveStatus);

        const adverbStatus = results.style.adverbsPer1000 > this.plugin.settings.analysis.maxAdverbsPer1000 ? 'bad' : 'good';
        this.updateMetric('Advérbios', `${results.style.adverbsPer1000.toFixed(0)}/1000`, adverbStatus);
            
        this.updateMetric('Frases longas', results.style.longSentenceCount.toString(), 
             results.style.longSentenceCount > 0 ? 'bad' : 'good');
    }

    updateMetric(label: string, value: string, status: 'good' | 'ok' | 'bad') {
        const metrics = this.containerEl.querySelectorAll('.swc-metric');
        for (let i = 0; i < metrics.length; i++) {
            const metric = metrics[i];
            const labelEl = metric.querySelector('.swc-metric__label');
            if (labelEl && labelEl.textContent === label) {
                const valueEl = metric.querySelector('.swc-metric__value');
                const dotEl = metric.querySelector('.swc-metric__dot');
                if (valueEl) valueEl.textContent = value;
                if (dotEl) {
                    dotEl.className = 'swc-metric__dot';
                    dotEl.classList.add(`swc-metric__dot--${status}`);
                }
                break;
            }
        }
    }
}

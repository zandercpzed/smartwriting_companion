import { requestUrl /*, RequestUrlParam */ } from 'obsidian';
import { LLMStatus, CompletionOptions, SWCSettings } from '../types';

export class LLMGateway {
    private settings: SWCSettings;

    constructor(settings: SWCSettings) {
        this.settings = settings;
    }

    public updateSettings(settings: SWCSettings) {
        this.settings = settings;
    }

    public async checkConnection(): Promise<LLMStatus> {
        // Only checking Ollama for now as it's the local priority
        if (this.settings.llm.preferLocal) {
            try {
                const response = await requestUrl({
                url: `${this.settings.llm.ollamaBaseUrl}/api/tags`,
                    method: 'GET',
                    throw: false
                });

                if (response.status === 200) {
                    return {
                        provider: 'ollama',
                        isConnected: true,
                        isLocal: true,
                        modelName: this.settings.llm.ollamaModel,
                        lastChecked: new Date()
                    };
                }
            } catch (e) {
                // Fall through to cloud check or return error
            }
        }

        // TODO: Implement checks for cloud providers?
        // Usually we just assume cloud is "connected" if API key is present.
        
        const provider = this.settings.llm.defaultCloudProvider;
        const hasKey = this.getApiKey(provider);

        if (hasKey) {
            return {
                provider: provider,
                isConnected: true,
                isLocal: false,
                modelName: provider,
                lastChecked: new Date()
            };
        }

        return {
            provider: null,
            isConnected: false,
            isLocal: false,
            modelName: null,
            lastChecked: new Date(),
            error: 'No valid provider found'
        };
    }

    public async complete(prompt: string, options?: CompletionOptions): Promise<string> {
        const status = await this.checkConnection();
        if (!status.isConnected || !status.provider) {
            throw new Error('No LLM provider connected');
        }

        if (status.provider === 'ollama') {
            return this.completeOllama(prompt, options);
        } else if (status.provider === 'gemini') {
            return this.completeGemini(prompt, options);
        } else if (status.provider === 'anthropic') {
            return this.completeAnthropic(prompt, options);
        }
        
        throw new Error(`Provider ${status.provider} not yet implemented`);
    }

    private async completeAnthropic(prompt: string, options?: CompletionOptions): Promise<string> {
        const apiKey = this.settings.llm.anthropicApiKey;
        if (!apiKey) throw new Error('No Anthropic API key configured');

        // Try to use the optional SDK if installed; otherwise fallback to HTTP API
        try {
            // dynamic require so project can work without the SDK installed
            // eslint-disable-next-line @typescript-eslint/no-var-requires
            const anthro = require('@anthropic-ai/claude-code+');
            // If the package exposes a client constructor, attempt to use it.
            // We guard this as the SDK may not be present or may have different exports.
            if (anthro && typeof anthro === 'object') {
                try {
                    const Client: any = anthro.Claude || anthro.ClaudeClient || anthro.Client || anthro.default;
                    if (Client) {
                            const client = new Client({ apiKey });
                        if (typeof client.chat === 'function') {
                            const sys = options?.systemPrompt ? options.systemPrompt + "\n\n" : '';
                            const res = await client.chat({ model: 'claude-2', messages: [{ role: 'system', content: sys }, { role: 'user', content: prompt }], max_tokens: options?.maxTokens });
                            // try common response shapes
                            return res?.output?.text || res?.completion || JSON.stringify(res);
                        }
                    }
                } catch (e) {
                    // fall through to HTTP fallback
                }
            }
        } catch (err) {
            // SDK not installed or failed to load; fallback to HTTP
        }

        // Fallback: call Anthropic HTTP API directly
        const body = {
            model: 'claude-2',
            messages: [{ role: 'system', content: options?.systemPrompt || '' }, { role: 'user', content: prompt }]
        };

        try {
            const response = await requestUrl({
                url: 'https://api.anthropic.com/v1/messages',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': apiKey,
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify(body)
            });

            if (response.status === 200) {
                const data = response.json as any;
                // Try common response fields
                if (data?.completion) return data.completion;
                if (data?.message?.content) return data.message.content;
                if (data?.choices && data.choices[0]) return data.choices[0].message?.content || data.choices[0].text || JSON.stringify(data.choices[0]);
                return JSON.stringify(data);
            } else {
                throw new Error(`Anthropic error: ${response.status}`);
            }
        } catch (error) {
            throw new Error(`Anthropic request failed: ${error}`);
        }
    }

    private async completeOllama(prompt: string, options?: CompletionOptions): Promise<string> {
        const body = {
            model: this.settings.llm.ollamaModel,
            prompt: prompt,
            stream: false,
            options: {
                temperature: options?.temperature || 0.7,
                num_predict: options?.maxTokens || 2048
            },
            system: options?.systemPrompt
        };

        try {
            const response = await requestUrl({
                url: `${this.settings.llm.ollamaBaseUrl}/api/generate`,
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });

            if (response.status === 200) {
                return JSON.parse(response.json).response;
            } else {
                throw new Error(`Ollama error: ${response.status}`);
            }
        } catch (error) {
             throw new Error(`Ollama connection failed: ${error}`);
        }
    }

    private async completeGemini(prompt: string, options?: CompletionOptions): Promise<string> {
        // POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}
         const model = 'gemini-pro'; // Or configurable
         const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${this.settings.llm.geminiApiKey}`;
         
         const body = {
             contents: [{
                 parts: [{ text: (options?.systemPrompt ? options.systemPrompt + "\\n\\n" : "") + prompt }]
             }],
             generationConfig: {
                 temperature: options?.temperature || 0.7,
                 maxOutputTokens: options?.maxTokens || 2048
             }
         };

         try {
            const response = await requestUrl({
                url: url,
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });

            if (response.status === 200) {
                const data = response.json;
                return data.candidates[0].content.parts[0].text;
            } else {
                 throw new Error(`Gemini error: ${response.status}`);
            }
        } catch (error) {
             throw new Error(`Gemini request failed: ${error}`);
        }
    }

    private getApiKey(provider: string): string {
        switch (provider) {
            case 'gemini': return this.settings.llm.geminiApiKey;
            case 'openai': return this.settings.llm.openaiApiKey;
            case 'anthropic': return this.settings.llm.anthropicApiKey;
            default: return '';
        }
    }
}

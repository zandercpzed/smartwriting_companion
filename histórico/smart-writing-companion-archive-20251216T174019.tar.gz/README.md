# Smart Writing Companion

Projeto: Assistente editorial local-first para Obsidian.

Quick start

- Install dependencies: `npm ci`
- Dev build/watch: `npm run dev`
- Production build: `npm run build`

CI

This repo includes a GitHub Actions workflow at `.github/workflows/ci.yml` which runs typechecking and the build on push and pull requests.

const path = require('path');
const fs = require('fs');

function assertEqual(a, b, msg) {
  if (a !== b) throw new Error(msg || `Assertion failed: ${a} !== ${b}`);
}

async function run() {
  const root = path.resolve(__dirname, '..');
  const compiled = path.join(root, '.tmp_test', 'src', 'analyzers', 'StatisticsAnalyzer.js');
  if (!fs.existsSync(compiled)) {
    console.error('Compiled analyzer not found at', compiled);
    process.exit(2);
  }

  const { StatisticsAnalyzer } = require(compiled);
  const sa = new StatisticsAnalyzer();

  const simple = 'This is a sentence. This is another.';
  const res = sa.analyze(simple, { wpm: 200 });
  console.log('res', res);
  assertEqual(res.words, 7, 'word count should be 7');
  assertEqual(res.sentences, 2, 'should detect 2 sentences');
  assertEqual(res.paragraphs, 1, 'should detect 1 paragraph');

  const md = '---\ntitle: Test\n---\n# Heading\nHello world!';
  const res2 = sa.analyze(md);
  if (!(res2.words >= 2)) throw new Error('frontmatter should be stripped and words counted');

  const res3 = sa.analyze('apple banana apple apple', { keywords: ['apple', 'banana'] });
  if (!res3.keywordDensityPer1000) throw new Error('keywordDensityPer1000 missing');
  console.log('keyword densities', res3.keywordDensityPer1000);

  console.log('All tests passed');
}

run().catch(e => { console.error(e); process.exit(1); });

const fs = require('fs');
const path = require('path');

const compiled = path.join(__dirname, '..', '.tmp_test', 'src', 'analyzers', 'StatisticsAnalyzer.js');
if (!fs.existsSync(compiled)) {
  console.error('Compiled analyzer not found at', compiled);
  process.exit(2);
}

const { StatisticsAnalyzer } = require(compiled);
const sa = new StatisticsAnalyzer();

const target = process.argv[2] || path.join(__dirname, '..', 'docs', 'TESTE - A Economia da Atenção versus a Economia da Matéria_ Uma Análise Estrutural Comparativa entre o Tráfego de Informações e a Produção Tangível.md');
if (!fs.existsSync(target)) {
  console.error('Target file not found:', target);
  process.exit(2);
}

const text = fs.readFileSync(target, 'utf8');
const res = sa.analyze(text, { keywords: ['viu','sentiu','percebeu'] });
console.log('ANALYSIS RESULT:\n', JSON.stringify(res, null, 2));

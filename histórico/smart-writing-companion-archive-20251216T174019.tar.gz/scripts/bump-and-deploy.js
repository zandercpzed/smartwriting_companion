#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const pkgPath = path.join(root, 'package.json');
const manifestPath = path.join(root, 'manifest.json');
const versionsPath = path.join(root, 'versions.json');

const vaultDest = path.join(root, '.obsidian', 'plugins', 'smart-writing-companion');

function readJSON(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

function writeJSON(p, obj) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2) + '\n', 'utf8');
}

function bumpPatch(version) {
  const parts = version.split('.').map(Number);
  parts[2] = (parts[2] || 0) + 1;
  return parts.join('.');
}

function run(cmd, args, opts = {}) {
  const res = spawnSync(cmd, args, { stdio: 'inherit', shell: false, ...opts });
  if (res.status !== 0) {
    throw new Error(`${cmd} ${args.join(' ')} failed`);
  }
}

function main() {
  console.log('Reading package.json and manifest.json...');
  const pkg = readJSON(pkgPath);
  const manifest = readJSON(manifestPath);
  const versions = fs.existsSync(versionsPath) ? readJSON(versionsPath) : {};

  const newVersion = bumpPatch(pkg.version || manifest.version || '0.0.0');
  console.log(`Bumping version to ${newVersion}`);

  pkg.version = newVersion;
  manifest.version = newVersion;
  versions[newVersion] = manifest.minAppVersion || versions[newVersion] || 'unknown';

  writeJSON(pkgPath, pkg);
  writeJSON(manifestPath, manifest);
  writeJSON(versionsPath, versions);

  console.log('Running build...');
  run('npm', ['run', 'build'], { cwd: root });

  console.log('Copying build artifacts to vault...');
  if (!fs.existsSync(vaultDest)) {
    fs.mkdirSync(vaultDest, { recursive: true });
  }
  const files = ['main.js', 'manifest.json', 'styles.css', 'versions.json'];
  files.forEach(f => fs.copyFileSync(path.join(root, f), path.join(vaultDest, f)));

  console.log('Done. New version:', newVersion);
}

try { main(); } catch (e) { console.error(e); process.exit(1); }

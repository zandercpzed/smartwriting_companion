const fs = require('fs');
const path = require('path');

const target = process.argv[2] || path.join(__dirname, '..', 'docs', 'TESTE - A Economia da Atenção versus a Economia da Matéria_ Uma Análise Estrutural Comparativa entre o Tráfego de Informações e a Produção Tangível.md');
if (!fs.existsSync(target)) {
  console.error('Target file not found:', target);
  process.exit(2);
}

const text = fs.readFileSync(target, 'utf8');

function naiveSplit(text) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

function asciiWords(text) {
  return (text.match(/\b[A-Za-z0-9']+\b/g) || []).length;
}

function unicodeWords(text) {
  return (text.match(/[\p{L}\p{N}'’-]+/gu) || []).length;
}

function unicodeWordsStripMarkdown(text) {
  const clean = text
    .replace(/^#+\s+/gm, '')
    .replace(/(\*\*|__)(.*?)\1/g, '$2')
    .replace(/(\*|_)(.*?)\1/g, '$2')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/!\[([^\]]*)\]\([^)]+\)/g, '')
    .replace(/^>\s+/gm, '')
    .replace(/```[\s\S]*?```/g, '')
    .replace(/`([^`]+)`/g, '$1');
  return (clean.match(/[\p{L}\p{N}'’-]+/gu) || []).length;
}

console.log('File:', target);
console.log('Naive split:', naiveSplit(text));
console.log('ASCII regex:', asciiWords(text));
console.log('Unicode regex:', unicodeWords(text));
console.log('Unicode + stripMarkdown:', unicodeWordsStripMarkdown(text));

// Print first 200 tokens for inspection
const tokens = (text.match(/[\p{L}\p{N}'’-]+/gu) || []).slice(0,200);
console.log('\nFirst 200 unicode tokens sample:\n', tokens.join(' | '));

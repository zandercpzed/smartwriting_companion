const fs = require('fs');
const path = require('path');

const statsPath = path.join(__dirname,'..','.tmp_test','src','analyzers','StatisticsAnalyzer.js');
const readPath = path.join(__dirname,'..','.tmp_test','src','analyzers','ReadabilityAnalyzer.js');
if (!fs.existsSync(statsPath) || !fs.existsSync(readPath)) {
  console.error('Compiled analyzers not found. Run npx tsc --outDir .tmp_test');
  process.exit(2);
}
const { StatisticsAnalyzer } = require(statsPath);
const { ReadabilityAnalyzer } = require(readPath);
const sa = new StatisticsAnalyzer();
const ra = new ReadabilityAnalyzer();
const target = process.argv[2] || path.join(__dirname,'..','docs','TESTE - A Economia da Atenção versus a Economia da Matéria_ Uma Análise Estrutural Comparativa entre o Tráfego de Informações e a Produção Tangível.md');
const text = fs.readFileSync(target,'utf8');
const sres = sa.analyze(text);
const rres = ra.getTextStats(text);
console.log('StatisticsAnalyzer words:', sres.words, 'readingTime:', sres.readingTimeMinutes, 'wordsPer1000:', sres.wordsPer1000);
console.log('ReadabilityAnalyzer words:', rres.words, 'sentences:', rres.sentences, 'syllables:', rres.syllables);

// compute frequency table from readability's wordList (lowercased, stripped)
const wl = rres.wordList.map(w=>w.toLowerCase().replace(/^['"“”‘’]+|['"“”‘’]+$/g,'')).filter(Boolean);
const freq = {};
for (const w of wl) freq[w]=(freq[w]||0)+1;
const entries = Object.entries(freq).sort((a,b)=>b[1]-a[1]);
console.log('\nTop 30 terms:');
for (let i=0;i<30 && i<entries.length;i++){ const [w,c]=entries[i]; console.log(i+1,w,c,(c/wl.length*100).toFixed(2)+'%',Math.round(c/wl.length*1000*10)/10); }

import { Plugin, WorkspaceLeaf } from 'obsidian';
import { SWCSettings, DEFAULT_SETTINGS } from './src/types/settings';
import { SWCSettingTab } from './src/settings/SettingsTab';
import { CompanionView, VIEW_TYPE_COMPANION } from './src/views/CompanionView';
import { AnalysisService, CleanupService, PersonaService } from './src/services';
import { LLMGateway } from './src/gateway';
import { ICON_DATA_URL, ICON_SVG } from './src/assets/icon-text-companion-sparkle';

/**
 * Entry point for the SmartWriting Companion Obsidian Plugin.
 * Manages lifecycle (onload, onunload), service instantiation, and View registration.
 */
export default class SmartWritingCompanion extends Plugin {
	settings: SWCSettings;
	analysisService: AnalysisService;
	cleanupService: CleanupService;
	personaService: PersonaService;
	llmGateway: LLMGateway;
    swcSettingTab?: SWCSettingTab;

	async onload() {
		await this.loadSettings();

		// Initialize services
		this.analysisService = new AnalysisService(this.settings);
		this.cleanupService = new CleanupService(this.settings);
		this.llmGateway = new LLMGateway(this.settings);
		this.personaService = new PersonaService(this.settings, this.llmGateway);

		this.registerView(
			VIEW_TYPE_COMPANION,
			(leaf) => new CompanionView(leaf, this)
		);

		this.addRibbonIcon('book-open', 'SmartWriting Companion', () => {
			this.activateView();
		});

		// Replace ribbon icon visuals to use the same emoji as the sidebar header
		this.app.workspace.onLayoutReady(() => {
			setTimeout(() => {
				const items = document.querySelectorAll('.workspace-ribbon-action');
				items.forEach((el) => {
					if ((el as HTMLElement).getAttribute('aria-label') === 'SmartWriting Companion') {
						const icon = (el as HTMLElement).querySelector('svg, i');
						if (icon) icon.remove();
						const wrapper = document.createElement('span');
						wrapper.className = 'swc-ribbon-icon-wrapper';
						wrapper.innerHTML = ICON_SVG;
						(el as HTMLElement).prepend(wrapper);
					}
				});
			}, 300);
		});

		this.addCommand({
			id: 'open-smart-writing-companion',
			name: 'Open SmartWriting Companion',
			callback: () => {
				this.activateView();
			}
		});

		// Keep a single reference to our settings tab so we can focus it programmatically
		this.swcSettingTab = new SWCSettingTab(this.app, this);
		this.addSettingTab(this.swcSettingTab);

        // Add header icon to markdown views
        this.registerEvent(this.app.workspace.on('file-open', (file) => {
             const leaf = this.app.workspace.getLeaf(false);
             if (leaf) this.addIconToHeader(leaf);
        }));
        this.registerEvent(this.app.workspace.on('active-leaf-change', (leaf) => {
            if (leaf) this.addIconToHeader(leaf);
        }));
        
        // Add to existing
        this.app.workspace.onLayoutReady(() => {
             this.app.workspace.iterateAllLeaves((leaf) => {
                 this.addIconToHeader(leaf);
             });
        });
	}

	async onunload() {
        // Clean up icons if needed, though they usually disappear with the view or on disable
	}

    addIconToHeader(leaf: WorkspaceLeaf) {
        if (!leaf.view) return;
        // Check if it's a MarkdownView (or loose check for having addAction)
        if (leaf.view.getViewType() === 'markdown') {
            const view = leaf.view as any;
            // Avoid duplicates: check if we already added it. 
            // Since we can't easily check internal state, checking the DOM for a unique class or tooltip is a way.
            const existing = view.containerEl.querySelector('.swc-header-action');
            if (existing) return;

			const action = view.addAction('book-open', 'Open SmartWriting Companion', () => {
				this.activateView();
			});
			// Replace the action icon with the same svg image to match sidebar
			const btn = view.containerEl.querySelector('.swc-header-action');
			if (btn) {
				const ico = btn.querySelector('svg, i');
				if (ico) ico.remove();
				const wrapper = document.createElement('span');
				wrapper.className = 'swc-header-action-svg';
				wrapper.innerHTML = ICON_SVG;
				btn.prepend(wrapper);
			}
            action.classList.add('swc-header-action');
        }
    }

	async loadSettings() {
		this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
	}

	async saveSettings() {
		await this.saveData(this.settings);
	}

	async activateView() {
		const { workspace } = this.app;

		let leaf: WorkspaceLeaf | null = null;
		const leaves = workspace.getLeavesOfType(VIEW_TYPE_COMPANION);

		if (leaves.length > 0) {
			leaf = leaves[0];
		} else {
			const rightLeaf = workspace.getRightLeaf(false);
			if (rightLeaf) {
				leaf = rightLeaf;
				await leaf.setViewState({ type: VIEW_TYPE_COMPANION, active: true });
			}
		}

		if (leaf) {
			workspace.revealLeaf(leaf);
		}
	}


	/**
	 * Open the Obsidian settings modal and focus this plugin's settings tab.
	 * Uses a short retry loop to wait for the settings UI to be available.
	 */
	async openAndFocusSettings() {
		const appAny = this.app as any;
		try {
			if (appAny.commands && typeof appAny.commands.executeCommandById === 'function') {
				await appAny.commands.executeCommandById('app:open-settings');
			} else if (typeof appAny.openSettings === 'function') {
				appAny.openSettings();
			}
		} catch (e) {
			// If open fails, swallow and continue to attempt focusing our tab below.
		}

		// Wait for settings modal to render, then call our settings tab display()
		for (let i = 0; i < 8; i++) {
			if (this.swcSettingTab) {
				try {
					this.swcSettingTab.display();
					return;
				} catch (e) {
					// ignore and retry
				}
			}
			await new Promise(resolve => setTimeout(resolve, 150));
		}
	}
}
